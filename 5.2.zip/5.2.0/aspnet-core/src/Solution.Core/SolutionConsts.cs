﻿namespace Solution
{
    public class SolutionConsts
    {
        public const string LocalizationSourceName = "Solution";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}
